## Your first script

days <- 365
#The output of this script is the probablity of that 
#there exsits two people who have the same birthday

birthday <- function(num, times = 400) {
  x <-  replicate(times, {
    temp <- table(sample(1:days, size = num, replace = TRUE))
    any(temp > 1)
  })
  mean(x)
}

for(i in 2:50){
  if(birthday(i)>=0.5){
    print(i)
    break  
  }
}

